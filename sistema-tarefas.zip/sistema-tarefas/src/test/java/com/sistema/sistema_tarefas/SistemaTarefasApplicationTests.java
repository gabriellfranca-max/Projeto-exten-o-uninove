package com.sistema.sistema_tarefas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaTarefasApplicationTests {

	@Test
	void contextLoads() {
	}

}
