package com.sistema.sistema_tarefas;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaTarefasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaTarefasApplication.class, args);
	}

}
